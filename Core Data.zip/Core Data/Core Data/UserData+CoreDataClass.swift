//
//  UserData+CoreDataClass.swift
//  Core Data
//
//  Created by MAC on 05/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//
//

import Foundation
import CoreData

@objc(UserData)
public class UserData: NSManagedObject {

}
