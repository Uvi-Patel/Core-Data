//
//  DataBaseHelper.swift
//  Core Data
//
//  Created by MAC on 05/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DataBaseHelper{
    
    static var sharedInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String:String]){
        let userdata = NSEntityDescription.insertNewObject(forEntityName: "UserData", into: context!) as! UserData
        userdata.name = object["name"]
        userdata.email = object["email"]
        userdata.phonenumber = object["phone"]
        
        do{
            try context?.save()
        } catch {
            print("Data is Not Save")
        }
    }
    
    func getUserData() -> [UserData]{
        
        var userdata = [UserData]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "UserData")
       // fetchRequest.predicate = NSPredicate(format: "name = %@")
        do{
            userdata = try context?.fetch(fetchRequest) as! [UserData]
        } catch{
            print("Can not Get Data")
        }
        return userdata
    }
    
    func deleteData(index:Int) -> [UserData]{
        
        var userdata = getUserData()
        context?.delete(userdata[index])
        userdata.remove(at: index)
        do{
            try context?.save()
        } catch {
            print("Can Not Delete Data")
        }
        return userdata
    }
    
    func editData(object:[String:String], i:Int){
        var userdata = getUserData()
        userdata[i].name = object["name"]
        userdata[i].email = object["email"]
        userdata[i].phonenumber = object["phone"]
        do{
            try context?.save()
        } catch {
            print("Data is Not Edit")
        }
    }
    
   
}
