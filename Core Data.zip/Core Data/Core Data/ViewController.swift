//
//  ViewController.swift
//  Core Data
//
//  Created by MAC on 05/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblView: UITableView!
    //    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnAdd: UIBarButtonItem!
    
    var userdata = [UserData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        tblView.delegate = self
//        tblView.dataSource = self
        userdata = DataBaseHelper.sharedInstance.getUserData()
        self.tblView.reloadData()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.userdata = DataBaseHelper.sharedInstance.getUserData()
          self.tblView.reloadData()
      }
     
    @IBAction func btnAddClick(_ sender: Any) {
       let insertVC = self.storyboard?.instantiateViewController(identifier: "InsertVC") as! InsertVC
        self.navigationController?.pushViewController(insertVC, animated: true)

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.lblName.text = "Name : \( String(describing: userdata[indexPath.row].name ?? ""))"
        cell.lblEmail.text = "Email : \( String(describing: userdata[indexPath.row].email ?? ""))"
        cell.lblPhone.text = "Phone : \( String(describing: userdata[indexPath.row].phonenumber ?? ""))"
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            userdata = DataBaseHelper.sharedInstance.deleteData(index: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let insertVC = self.storyboard?.instantiateViewController(identifier: "InsertVC") as! InsertVC
        
        let dict: NSDictionary =
            ["name": userdata[indexPath.row].name,"email":userdata[indexPath.row].email,"phone":userdata[indexPath.row].phonenumber]
        insertVC.dict = dict
        insertVC.i = indexPath.row
        insertVC.isUpdate = true
        
        self.navigationController?.pushViewController(insertVC, animated: true)
        
    }
  
}


