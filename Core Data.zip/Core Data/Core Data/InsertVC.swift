//
//  InsertVC.swift
//  Core Data
//
//  Created by MAC on 05/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import  CoreData

class InsertVC: UIViewController {
   
    @IBOutlet weak var lblValidation: UILabel!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var btnInsert: UIButton!

    var validation = Validation()
    var i = Int()
    var isUpdate = Bool()
    var dict: NSDictionary?

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        btnInsert.addTarget(self, action: #selector(btnSaveClick(_:)), for: .touchUpInside)
        
        txtName.autocorrectionType = .no
        txtEmail.autocorrectionType = .no
        txtPhone.autocorrectionType = .no
        
        txtName.text = dict?.value(forKey: "name") as? String
        txtEmail.text = dict?.value(forKey: "email") as? String
        txtPhone.text = dict?.value(forKey: "phone") as? String
    }
   
    @IBAction func btnSaveClick(_ sender: Any) {
        
        guard let name = txtName.text, let email = txtEmail.text,
            let phone = txtPhone.text else {
                return
        }
        let isValidateName = self.validation.validateName(name: name)
        if (isValidateName == false) {
            lblValidation.text = "Incorrect Name"
            print("Incorrect Name")
            return
         }
         let isValidateEmail = self.validation.validateEmailId(emailID: email)
         if (isValidateEmail == false) {
            lblValidation.text = "Incorrect Email"
            print("Incorrect Email")
            return
         }
     
         let isValidatePhone = self.validation.validaPhoneNumber(phoneNumber: phone)
         if (isValidatePhone == false) {
            lblValidation.text = "Incorrect Phone"
            print("Incorrect Phone")
            return
         }
         if (isValidateName == true || isValidateEmail == true ||  isValidatePhone == true) {
            print("All fields are correct")
         }
        let dict = ["name":txtName.text ,"email":txtEmail.text,"phone":txtPhone.text]
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserData")
        let predicate = NSPredicate(format: "name == %@", txtName.text!)
            request.predicate = predicate
//            request.fetchLimit = 1

            do{
//                let app = UIApplication.shared.delegate as! AppDelegate
//                let context = app.managedObjectContext
                let count = try DataBaseHelper.sharedInstance.context?.count(for: request)
                if count == 0 {
                    // no matching object
//                    print("no present")

                    if isUpdate {
                        DataBaseHelper.sharedInstance.editData(object: dict as! [String:String], i: i)
                    }else {
                        DataBaseHelper.sharedInstance.save(object: dict as! [String : String])
                    }
                }
                else{
                    // at least one matching object exists
                    print("one matching item found")
                    let alert = UIAlertController(title: "Alert", message: "one matching item found", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
            catch { }
        self.navigationController?.popViewController(animated: true)
    }

    func data(object: [String : String], index:Int, isEdit: Bool) {
      
        txtName.text = object["name"]
        txtEmail.text = object["email"]
        txtPhone.text = object["phone"]
        i = index
        isUpdate = isEdit
    }

}

class Validation {
    func validateName(name: String) ->Bool {
      // Length be 18 characters max and 3 characters minimum, you can always modify.
      let nameRegex = "^\\w{3,18}$"
      let trimmedString = name.trimmingCharacters(in: .whitespaces)
      let validateName = NSPredicate(format: "SELF MATCHES %@", nameRegex)
      let isValidateName = validateName.evaluate(with: trimmedString)
      return isValidateName
    }
    
    func validaPhoneNumber(phoneNumber: String) -> Bool {
      let phoneNumberRegex = "^[6-9]\\d{9}$"
      let trimmedString = phoneNumber.trimmingCharacters(in: .whitespaces)
      let validatePhone = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
      let isValidPhone = validatePhone.evaluate(with: trimmedString)
      return isValidPhone
    }
    
    func validateEmailId(emailID: String) -> Bool {
      let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
      let trimmedString = emailID.trimmingCharacters(in: .whitespaces)
      let validateEmail = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
      let isValidateEmail = validateEmail.evaluate(with: trimmedString)
      return isValidateEmail
    }
  
}
