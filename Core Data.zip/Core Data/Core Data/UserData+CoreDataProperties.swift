//
//  UserData+CoreDataProperties.swift
//  Core Data
//
//  Created by MAC on 05/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//
//

import Foundation
import CoreData


extension UserData {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserData> {
        return NSFetchRequest<UserData>(entityName: "UserData")
    }

    @NSManaged public var email: String?
    @NSManaged public var name: String?
    @NSManaged public var phonenumber: String?


}
