//
//  UpdateVC.swift
//  Core Data
//
//  Created by MAC on 05/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class UpdateVC: UIViewController, DataPass {
    
    
    @IBOutlet weak var txtName: UITextField!
    
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    var i = Int()
    //var isUpdate = Bool()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnShowData(_ sender: Any) {
        let VC = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
        VC.delegate = self
        self.navigationController?.pushViewController(VC, animated: true)
    }
    @IBAction func btnUpdateClick(_ sender: Any) {
        let dict = ["name" : txtName.text, "email" : txtEmail.text, "phone" : txtPhone.text]
         DataBaseHelper.sharedInstance.editData(object: dict as! [String:String], i: i)
    }
    func data(object: [String : String], index: Int) {
        
            txtName.text = object["name"]
            txtEmail.text = object["email"]
            txtPhone.text = object["phone"]
            i = index
           // isUpdate = isEdit
        
    }
}
